# Affen-Abwehr

Tower-Defense im Stil von Bloons TD 6, im Pixel-Look. Eine einzige HTML-Datei, keine Abhängigkeiten.

## Starten
`index.html` im Browser öffnen oder GitHub Pages aktivieren (Settings > Pages > Branch `main`, Ordner `/root`).

## Spielprinzip
- 3 Karten, 40 Runden, Affen, Held und Fallen platzieren und in 3 Stufen aufwerten.
- Tempo ×1 bis ×4 und Auto-Start (Runden starten automatisch).
- Roguelike: Perk-Auswahl vor dem Spiel und alle 10 Runden. Siege schalten Affen (Scharfschütze 1, Helikopter 3, Superaffe 10) und Karten frei.
- Spielstand liegt im localStorage des Browsers.

## Admin-Menü
Im Hauptmenü auf "Admin" klicken, Benutzername `Max`, Passwort `Susik1`. Dort: unendlich Geld, unendlich Leben, Pfeilsturm ohne Pause, alles freigeschaltet, Auto-Start, Spielstand löschen. (Clientseitig, kein echter Schutz.)
